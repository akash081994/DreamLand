   @yield('exfooter')
 <!-- @extends('layouts.master')
 @section('content123') -->
<h2>I am footer</h2>
<!-- @endsection -->