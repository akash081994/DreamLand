<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
       @extends('layouts.exampleheader')
       @section('exheader')
   <h1>This is master page</h1>

  
        @extends('layouts.examplefooter')
        @section('exfooter')


</body>
</html>