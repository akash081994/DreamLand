<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSubmitPropertiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('submit_properties', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('userId')->default(1);
          //  $table->foreign('commonuserId')->references('id')->on('common_users')
          //   ->onDelete('cascade'); 
            $table->string('sellerImage');
            $table->string('propertyName')->unique();
            $table->string('propertyPrice');
            $table->integer('mobileNo');
            $table->string ('propertDescription')->nullable();
            $table->string('propertyState')->nullable();
            $table->string('propertyCity')->nullable();
            $table->string('propertyStatue')->nullable();
            $table->string('lease');
            $table->string('Min_bed')->nullable();
            $table->string('Property_geo');
            $table->string('Swimming_Pool')->nullable();
            $table->string('Stories')->nullable();
            $table->string('Emergency_Exit')->nullable();
            $table->string('Fire_Place')->nullable();
            $table->string('Laundry_Room')->nullable();
            $table->string('Jog_Path')->nullable();
            $table->string('Ceilings')->nullable();
            $table->string('Dual_Sinks')->nullable();
           // $table->string('property_images')->nullable();
            $table->string('propertyVideo');
            $table->timestamps();

             
           
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('submit_properties');
    }
}
