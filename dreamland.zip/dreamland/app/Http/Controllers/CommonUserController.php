<?php

namespace App\Http\Controllers;

use App\commonUser;
use Illuminate\Http\Request;

class CommonUserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\commonUser  $commonUser
     * @return \Illuminate\Http\Response
     */
    public function show(commonUser $commonUser)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\commonUser  $commonUser
     * @return \Illuminate\Http\Response
     */
    public function edit(commonUser $commonUser)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\commonUser  $commonUser
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, commonUser $commonUser)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\commonUser  $commonUser
     * @return \Illuminate\Http\Response
     */
    public function destroy(commonUser $commonUser)
    {
        //
    }
}
