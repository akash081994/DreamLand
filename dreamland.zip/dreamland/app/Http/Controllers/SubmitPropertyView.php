<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;
use App\SubmitProperty;

class SubmitPropertyView extends Controller
{
	public function show(){
    // $users = DB::select('select * from submit_properties limit 6');
    //      return view('proplist',['users'=>$users]);

         $users = SubmitProperty::paginate(6);

          return view('proplist', compact('users'));
     }


    //  public function showdetail(){
    // $users = DB::select('select * from submit_properties');
    //      return view('property-1',['users'=>$users]);
    //  }

    //   public function pagination()
    // {
    //    $users =SubmitProperty::all();
       
    //     return view('proplist',compact('users'));
    // }

     

     public function showAftrtLogin(){
    // $users = DB::select('select * from submit_properties limit 6');
    //      return view('proplist',['users'=>$users]);

         $users = SubmitProperty::paginate(6);

          return view('afterlogin', compact('users'));
     }
      public function showDetail($id)
     {
          $detail = SubmitProperty::where('id', $id)->with('user')->first(); 
       //$detail = SubmitProperty::where('id', $id)->with('user')->get();
        //$detail = SubmitProperty::with('user')->find($id);
         // dd($detail->user->name);
           return view('property-1',compact('detail'));

            //$detail =SubmitProperty::with('user')->get()->find($id);
          //$detail = SubmitProperty::with('user')->findOrFail($id);

            //  dd($detail->name);
            // return view('property-1')->with(['users' => $users]);
     }



     public function similerProperty()
     {
          $property = SubmitProperty::get(4);

          return view('property-1', compact('property'));
     }
    

    // public function userProfile(
    // {
    //      $profile = User::get();

    //      return view()
    // })



}
