<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class dreamlandController extends Controller
{
    // function inddex()
    // {
    // 	return view('index');
    // }

    // function propertiesTwo()
    // {
    // 	return view('propertiesTwo');
    // }

	   function register()
	   {
	   	   return view('register');
	   }



}
