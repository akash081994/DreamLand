<?php

namespace App\Http\Controllers;

use App\SubmitProperty;
use Illuminate\Http\Request;

class SubmitPropertyController extends Controller
{
    public function __construct(SubmitProperty $submitProperty){
         $this->submitProperty =$submitProperty;
    }
    

    public function insertform(){
        return view('submit-property');
    }
    public function insert(Request $request)
    {

        
        //Start Validation code
           // $this->validate($request,[
           //   "sellerImg"         =>"image",
           //   "propertyname"      =>"alpha|max:50|min:5",
           //   "propertyprice"     =>"integer|max:20|min:5",
           //   "phone"             =>"integer|max:20|min:10",
           //   "discrition"        =>"alpha_dash|min:10|max:100",
           //   "propState"         =>"alpha|min:3|max:20",
           //   "propCity"          =>"alpha|min:3|max:20",
           //   "minBed"            =>"integer|min:1|max:5",
           //   "propgeo"           =>"integer|min:3|max:10"
             
           //   ],[ 
               //Custom error messages
             // "sellerImg.image"      =>"Image should be jpg,png,bmp or gif",
             // "propertyname.alpha"   =>"Prperty Name should be letters",
             // "propertyname.max"     =>"Prperty Name Maximum 50 Characters",
             // "propertyname.min"     =>"Prperty Name atleast 5 Characters",
             // "propertyprice.max"=>"Property price may not be greater than 10 digits",
             // "propertyprice.min"=>"Property price may not be less than 5 digits"
                
            // ]);

           // print_r($request->all());
           // dd();

            

        $file =$request->file("sellerImg");
       

         if($request->hasFile("sellerImg"))
              {
                  $file = $request->file("sellerImg");
                  $file->move("upload/",$file->getClientOriginalName());
              }

      
             
         
        $sellerimage        = $request->file('sellerImg')->getClientOriginalName();
        $propertyName       = $request->input('propertyname');
        $propertyPrice      = $request->input('propertyprice');
        $mobileNo           = $request->input('phone');
        $propertDescription = $request->input('discrition');
        $propertyState      = $request->input('propState');
        $propertyCity       = $request->input('propCity');
        $propertyStatue     = $request->input('propStatue');
        $lease              = $request->input('leaseperiod');
        $Min_bed            = $request->input('minBed');
        $Property_geo       = $request->input('propgeo');
        $Swimming_Pool      = $request->input('swimpool');
        $Stories            = $request->input('stories');
        $Emergency_Exit     = $request->input('emergencyEx');
        $Fire_Place         = $request->input('fireplace');
        $Laundry_Room       = $request->input('laundryRoom');
        $Jog_Path           = $request->input('jogpath');
        $Ceilings           = $request->input('ceiling');
        $Dual_Sinks         = $request->input('dualsinks');
        $propertyVideo      = $request->input('property_video');
        
             




        $submitProperty=$this->submitProperty
        ->create([
                 'sellerimage'        => $sellerimage,
                 'propertyName'       => $propertyName,
                 'propertyPrice'      => $propertyPrice,
                 'mobileNo'           => $mobileNo,
                 'propertDescription' => $propertDescription,
                 'propertyState'      => $propertyState,
                 'propertyCity'       => $propertyCity,
                 'propertyStatue'     => $propertyStatue,
                 'lease'              => $lease,
                 'Min_bed'            => $Min_bed ,
                 'Property_geo'       => $Property_geo ,
                 'Swimming_Pool'      => $Swimming_Pool,
                 'Stories'            => $Stories ,
                 'Emergency_Exit'     => $Emergency_Exit,
                 'Fire_Place'         => $Fire_Place ,
                 'Laundry_Room'       => $Laundry_Room ,
                 'Jog_Path'           => $Jog_Path ,
                 'Ceilings'           => $Ceilings ,
                 'Dual_Sinks'         => $Dual_Sinks ,
                 'propertyVideo'      => $propertyVideo

                
            ]);
             if($submitProperty==true)
             {
                 return redirect('index')->with('message','Post is insert successfully');
             }
            
        
       

    }

   
}
