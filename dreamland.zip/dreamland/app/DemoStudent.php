<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DemoStudent extends Model
{
    //
}
