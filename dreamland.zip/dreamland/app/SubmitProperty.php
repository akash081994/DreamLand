<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubmitProperty extends Model
{
    protected $fillable = [
        'userId','sellerimage', 'propertyName', 'propertyPrice','mobileNo','propertDescription','propertyState','propertyCity','propertyStatue','lease','Min_bed','Property_geo','Swimming_Pool','Stories','Emergency_Exit','Fire_Place','Laundry_Room','Jog_Path','Ceilings','Dual_Sinks','property_images','propertyVideo',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'userId', 'id');
    }
}
