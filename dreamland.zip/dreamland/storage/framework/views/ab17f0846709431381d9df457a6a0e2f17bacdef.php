<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> 
<html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>GARO ESTATE | Submit property Page</title>
        <meta name="description" content="GARO is a real-estate template">
        <meta name="author" content="Kimarotec">
        <meta name="keyword" content="html5, css, bootstrap, property, real-estate theme , bootstrap template">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800' rel='stylesheet' type='text/css'>

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
        <link rel="icon" href="favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="/css/normalize.css">
        <link rel="stylesheet" href="/css/font-awesome.min.css">
        <link rel="stylesheet" href="/css/fontello.css">
        <link href="/fontss/icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet">
        <link href="/fontss/icon-7-stroke/css/helper.css" rel="stylesheet">
        <link href="css/animate.css" rel="stylesheet" media="screen">
        <link rel="stylesheet" href="/css/bootstrap-select.min.css"> 
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/icheck.min_all.css">
        <link rel="stylesheet" href="/css/price-range.css">
        <link rel="stylesheet" href="/css/owl.carousel.css">  
        <link rel="stylesheet" href="/css/owl.theme.css">
        <link rel="stylesheet" href="/css/owl.transitions.css"> 
        <link rel="stylesheet" href="/css/wizard.css"> 
        <link rel="stylesheet" href="/css/style.css">
        <link rel="stylesheet" href="/css/responsive.css">
        <style >
             element.style {
    position: absolute;
    top: -20%;
    left: -20%;
    display: block;
    width: 140%;
    height: 140%;
    margin: 0px;
    padding: 0px;
    background: rgb(255, 255, 255);
    border: 0px;
    opacity: 1;
}
        </style>
    </head>
    <body>

        <div id="preloader">
            <div id="status">&nbsp;</div>
        </div>
        <!-- Body content -->

        
        <!--End top header -->

         <nav class="navbar navbar-default ">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(url('index')); ?>"><img src="/img/logo.png" alt=""></a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse yamm" id="navigation">
                    
                   <ul class="main-nav nav navbar-nav navbar-right">
                        
                         <li class="wow fadeInDown" data-wow-delay="0.1s"><a class="" href="<?php echo e(url('afterlogin')); ?>">Home</a></li>

                        <!-- <li class="wow fadeInDown" data-wow-delay="0.1s"><a class="" href="<?php echo e(url('view-records')); ?>">Property</a></li> -->
                        <li class="wow fadeInDown" data-wow-delay="0.1s"><a class="" href="<?php echo e(('afterlogin')); ?>">Buy</a></li>
                        <li class="wow fadeInDown" data-wow-delay="0.1s"><a class="" href="<?php echo e(('submitprop')); ?>">Sell</a></li>
                        

                        
                    </ul>                </div><!-- /.navbar-collapse-->
            </div><!-- /.container-fluid-->
        </nav>
        <!-- End of nav bar -->

        <div class="page-head"> 
            <div class="container">
                <div class="row">
                    <div class="page-head-content">
                        <h1 class="page-title">Submit new property</h1>               
                    </div>
                </div>
            </div>
        </div>
        <!-- End page header -->

        <!-- property area -->
       
        <div class="content-area submit-property" style="background-color: #FCFCFC;">&nbsp;
            <div class="container">
                <div class="clearfix" > 
                    <div class="wizard-container"> 

                        <div class="wizard-card ct-wizard-orange" id="wizardProperty">
                              <!--  <?php if($errors->any()): ?>
                                 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     
                                      <li class="alert alert-danger"><?php echo e($error); ?></li></script>
                                    
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <?php endif; ?>
 -->
                             <!--   <?php if(session('message')): ?>
                                 <p class="alert alert-danger"><?php echo e(session('message')); ?></p>
                                <?php endif; ?> -->

                            <form action="<?php echo e(url('insertion')); ?>" method="post" name="myForm" enctype="multipart/form-data" id="formId" >
                             <?php echo e(csrf_field()); ?>                        
                                <div class="wizard-header">
                                    <h3>
                                        <b>Submit</b> YOUR PROPERTY <br>
                                        
                                    </h3>
                                </div>

                                <ul>
                                    <li><a href="#step1" data-toggle="tab">Step 1 </a></li>
                                    <li><a href="#step2" data-toggle="tab">Step 2 </a></li>
                                    <li><a href="#step3" data-toggle="tab">Step 3 </a></li>
                                    <li><a href="#step4" data-toggle="tab">Finished </a></li>
                                </ul>

                                <div class="tab-content">

                                    <div class="tab-pane" id="step1">
                                        <div class="row p-b-15  ">
                                            <h4 class="info-text"> Let's start with the basic information (with validation)</h4>
                                            <div class="col-sm-4 col-sm-offset-1">
                                                <div class="picture-container">
                                                    <div class="picture">
                                                        <img src="/img/default-property.jpg" class="picture-src" id="wizardPicturePreview" title=""/>
                                                        <input type="file" id="wizard-picture" name="sellerImg"   value="<?php echo e(old('sellerImg')); ?>">
                                                    </div> 
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label>Property name <small>(required)</small></label>
                                                    <input name="propertyname" type="text" class="form-control"  value="<?php echo e(old('propertyname')); ?>" id="pronameid" >
                                                    <span style="color: red;" id="propertynameErrorMessage"></span>

                                <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('propertyname')); ?></strong>
                                            </span>
                                <?php endif; ?>
                                                </div>

                                                <div class="form-group">
                                                    <label>Property price <small>(required)</small></label>
                                                    <input name="propertyprice" type="text" class="form-control"  value="<?php echo e(old('propertyprice')); ?>" id="priceId" >
                                                    <span style="color: red;" id="propertyPriceErrorMessage"></span>
                                                </div> 
                                                <div class="form-group">
                                                    <label>Mobile No. <small>(empty if you wanna use default phone number)</small></label>
                                                    <input name="phone" type="text" class="form-control"  value="<?php echo e(old('phone')); ?>" id="mobileId" >
                                                    <span style="color: red;" id="mobileErrorMessage"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--  End step 1 -->

                                    <div class="tab-pane" id="step2">
                                        <h4 class="info-text"> How much your Property is Beautiful ? </h4>
                                        <div class="row">
                                            <div class="col-sm-12"> 
                                                <div class="col-sm-12"> 
                                                    <div class="form-group">
                                                        <label>Property Description :</label>
                                                        <textarea name="discrition" class="form-control" value="<?php echo e(old('discrition')); ?>" ></textarea>
                                                    </div> 
                                                </div> 
                                            </div>

                                            <div class="col-sm-12">
                                                <div class="col-sm-3">
                                                    <div class="form-group">
                                                        <label>Property State :</label>
                                                        <input name="propState" type="text" class="form-control" placeholder="State" value="<?php echo e(old('propState')); ?>" id="stateId" >
                                                        <span style="color: red;" id="stateErrorMessage"></span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-3">
                                                    <div class="form-group">
                                                        <label>Property City :</label>
                                                         <input name="propCity" type="text" class="form-control" placeholder="City" value="<?php echo e(old('propCity')); ?>" id="cityId" >
                                                         <span style="color: red;" id="cityErrorMessage"></span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-3">
                                                    <div class="form-group">
                                                        <label>Property Status  :</label>
                                                        <select id="" class="selectpicker show-tick form-control" name="propStatue" onchange="changeddl(this)">
                                                            <option value="-1"> -Status- </option>
                                                            <option value="1">Rent </option>
                                                            <option value="2">Buy</option>
                                                           

                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-sm-3">
                                                    <div class="form-group">
                                                        <label>Lease Preiod  :</label>
                                                        <select id="basic" class="selectpicker show-tick form-control" name="leaseperiod"  >
                                                            <option value="-1"> -None- </option>
                                                            <option value="1_21">6 Months </option>
                                                            <option value="1_22">1 Year</option>
                                                             <option value="1_23">2 Year</option>
                                                              <option value="1_24">3 Year</option>
                                                           

                                                        </select>
                                                    </div>
                                                </div>
                                                
                                            <div class="col-sm-12 padding-top-15">                                                   
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>Property Bed :</label>
                                                         <input name="minBed" type="text" class="form-control" placeholder="Bed" value="<?php echo e(old('minBed')); ?>" size="50" id="bedId" >
                                                         <span style="color: red;" id="bedErrorMessage"></span>
                                                    </div>                 
                                                    </div>
                                                
                                                <div class="col-sm-6">

                                                    <div class="form-group">
                                                        <label>Property Area :</label>
                                                         <input name="propgeo" type="text" class="form-control" placeholder="Area" value="<?php echo e(old('propgeo')); ?>" size="50" id="areaId" >
                                                         <span style="color: red;" id="areaErrorMessage"></span>
                                                    </div>
                                                </div>  
                                            </div>
                                            <div class="col-sm-12 padding-top-15">
                                                <div class="col-sm-3">
                                                    <div class="form-group">
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" name="swimpool" value="swimpool"> Swimming Pool
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <div class="col-sm-3">
                                                    <div class="form-group">
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" name="stories" value="stories"> 2 Stories
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>                                                 
                                                <div class="col-sm-3">
                                                    <div class="form-group">
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" name="emergencyEx" value="emergencyEx"> Emergency Exit
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>                                                 
                                                <div class="col-sm-3">
                                                    <div class="form-group">
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" name="fireplace" value="fireplace"> Fire Place 
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div> 
                                            <div class="col-sm-12 padding-bottom-15">
                                                <div class="col-sm-3">
                                                    <div class="form-group">
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" name="laundryRoom" value="laundryRoom"> Laundry Room
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-3">
                                                    <div class="form-group">
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" name="jogpath" value="jogpath"> Jog Path
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-3">
                                                    <div class="form-group">
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" name="ceiling" value="ceiling"> Ceilings
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-3">
                                                    <div class="form-group">
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" name="dualsinks" value="dualsinks"> Dual Sinks
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <br>
                                        </div>
                                    </div>
                                    </div>
                                    <!-- End step 2 -->

                                    <div class="tab-pane" id="step3">                                        
                                        <h4 class="info-text">Give us some videos ? </h4>
                                        <div class="row">  
                                            <div class="col-sm-6">
                                               <!-- <div class="form-group">
                                                    <div class="input-group control-group increment" >
                                                    <input type="file" id="wizard-picture" name="propertyimgs"   value="<?php echo e(old('propertyimgs')); ?>"> -->
         <!--  <input type="file" name="filename[]" class="form-control"> -->
          <!-- <div class="input-group-btn"> 
            <button class="btn btn-success" type="button"><i class="glyphicon glyphicon-plus"></i>Add</button>
          </div>
        </div>
         <div class="clone hide">
          <div class="control-group input-group" style="margin-top:10px">
            <input type="file" name="propertyimgs" value="<?php echo e(old('propertyimgs')); ?>"" class="form-control">
            <div class="input-group-btn"> 
              <button class="btn btn-danger" type="button"><i class="glyphicon glyphicon-remove"></i> Remove</button>
            </div>
          </div>
        </div> -->
 
                                                    <!-- <p class="help-block">Select multipel images for your property .</p> -->
                                                <!-- </div> -->
                                            </div>
 <!--  <div class="input-group control-group increment" >
          <input type="file" name="filename[]" class="form-control">
          <div class="input-group-btn"> 
            <button class="btn btn-success" type="button"><i class="glyphicon glyphicon-plus"></i>Add</button>
          </div>
        </div>
        <div class="clone hide">
          <div class="control-group input-group" style="margin-top:10px">
            <input type="file" name="filename[]" class="form-control">
            <div class="input-group-btn"> 
              <button class="btn btn-danger" type="button"><i class="glyphicon glyphicon-remove"></i> Remove</button>
            </div>
          </div>
        </div> -->







                                            <div class="col-sm-12"> 
                                                <div class="form-group">
                                                    <label for="property-video">Property video :</label>
                                                    <input class="form-control" value="" placeholder="http://www.youtube.com, http://vimeo.com" name="property_video" type="text">

                                                </div> 

                                                

                                                
                                            </div>
                                        </div>
                                    </div>
                                    <!--  End step 3 -->


                                    <div class="tab-pane" id="step4">                                        
                                        <h4 class="info-text"> Finished and submit </h4>
                                        <div class="row">  
                                            <div class="col-sm-12">
                                                <div class="">
                                                    <p>
                                                        <label><strong>Terms and Conditions</strong></label>
                                                        By accessing or using  GARO ESTATE services, such as 
                                                        posting your property advertisement with your personal 
                                                        information on our website you agree to the
                                                        collection, use and disclosure of your personal information 
                                                        in the legal proper manner
                                                    </p>

                                                    <div class="checkbox" >
                                                        <label>
                                                            <input type="checkbox" > <strong>Accept termes and conditions.</strong>
                                                        </label>

                                                    </div> 

                                                </div> 
                                            </div>
                                        </div>
                                    </div>
                                    <!--  End step 4 -->

                                </div>

                                <div class="wizard-footer">
                                    <div class="pull-right">
                                        <input type='button' class='btn btn-next btn-primary' name='next' value='Next' />
                                        <input type='submit' class='btn btn-finish btn-primary ' name='finish' value='Finish' />
                                    </div>

                                    <div class="pull-left">
                                        <input type='button' pe='submit' class='btn btn-previous btn-default' name='previous' value='Previous' />
                                    </div>
                                    <div class="clearfix"></div>                                            
                                </div>	
                            </form>
                        </div>
                        <!-- End submit form -->
                    </div> 
                </div>
            </div>
        </div>
        

          <!-- Footer area-->
        <div class="footer-area">

            <div class=" footer">
                <div class="container">
                    <div class="row">

                        <div class="col-md-4 col-sm-4 wow fadeInRight animated">
                            <div class="single-footer">
                                <h4>About us </h4>
                                <div class="footer-title-line"></div>

                                <img src="/img/footer-logo.png" alt="" class="wow pulse" data-wow-delay="1s">
                                <p>Lorem ipsum dolor cum necessitatibus su quisquam molestias. Vel unde, blanditiis.</p>
                                <ul class="footer-adress">
                                    <li><i class="pe-7s-map-marker strong"> </i> 9089 your adress her</li>
                                    <li><i class="pe-7s-mail strong"> </i> email@yourcompany.com</li>
                                    <li><i class="pe-7s-call strong"> </i> +1 908 967 5906</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 wow fadeInRight animated">
                            <div class="single-footer">
                                <h4>Quick links </h4>
                                <div class="footer-title-line"></div>
                                <ul class="footer-menu">
                                    <li><a href="properties-2.html">Properties</a>  </li> 
                                   
                                    <li><a href="contact.html">Contact us</a></li> 
                                    <li><a href="faq.html">fqa</a>  </li> 
                                    <li><a href="faq.html">Terms </a>  </li> 
                                </ul>
                            </div>
                        </div>
                        
                        <div class="col-md-4 col-sm-4 wow fadeInRight animated">
                            <div class="single-footer news-letter">
                                <h4>Stay in touch</h4>
                                <div class="footer-title-line"></div>
                                <p>Lorem ipsum dolor sit amet, nulla  suscipit similique quisquam molestias. Vel unde, blanditiis.</p>

                                <form>
                                    <div class="input-group">
                                        <input class="form-control" type="text" placeholder="E-mail ... ">
                                        <span class="input-group-btn">
                                            <button class="btn btn-primary subscribe" type="button"><i class="pe-7s-paper-plane pe-2x"></i></button>
                                        </span>
                                    </div>
                                    <!-- /input-group -->
                                </form> 

                                <div class="social pull-right"> 
                                    <ul>
                                        <li><a class="wow fadeInUp animated" href="https://twitter.com/kimarotec"><i class="fa fa-twitter"></i></a></li>
                                        <li><a class="wow fadeInUp animated" href="https://www.facebook.com/kimarotec" data-wow-delay="0.2s"><i class="fa fa-facebook"></i></a></li>
                                        <li><a class="wow fadeInUp animated" href="https://plus.google.com/kimarotec" data-wow-delay="0.3s"><i class="fa fa-google-plus"></i></a></li>
                                       
                                    </ul> 
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <div class="footer-copy text-center">
                <div class="container">
                    <div class="row">
                        <div class="pull-left">
                            <span> (C) <a href="http://www.KimaroTec.com">KimaroTheme</a> , All rights reserved 2016  </span> 
                        </div> 
                        <div class="bottom-menu pull-right"> 
                            <ul> 
                                <li><a class="wow fadeInUp animated" href="#" data-wow-delay="0.2s">Home</a></li>
                                <li><a class="wow fadeInUp animated" href="#" data-wow-delay="0.3s">Property</a></li>
                                <li><a class="wow fadeInUp animated" href="#" data-wow-delay="0.4s">Faq</a></li>
                                <li><a class="wow fadeInUp animated" href="#" data-wow-delay="0.6s">Contact</a></li>
                            </ul> 
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <script src="/js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="/js//jquery-1.10.2.min.js"></script>
        <script src="/js/bootstrap.min.js"></script>
        <script src="/js/bootstrap-select.min.js"></script>
        <script src="/js/bootstrap-hover-dropdown.js"></script>
        <script src="/js/easypiechart.min.js"></script>
        <script src="/js/jquery.easypiechart.min.js"></script>
        <script src="/js/owl.carousel.min.js"></script>
        <script src="/js/wow.js"></script>
        <script src="/js/icheck.min.js"></script>

        <script src="/js/price-range.js"></script> 
        <script src="/js/jquery.bootstrap.wizard.js" type="text/javascript"></script>
        <script src="/js/jquery.validate.min.js"></script>
        <script src="/js/wizard.js"></script>

        <script src="/js/main.js"></script>
         <script src="/js/validation.js"></script>
         <script src="/js/validationForSubmitProperty.js"></script>
         <script type="text/javascript">


    $(document).ready(function() {

      $(".btn-success").click(function(){ 
          
          
                 var html = $(".clone").html();
                $(".increment").after(html);   
        

      });

      $("body").on("click",".btn-danger",function(){ 
          $(this).parents(".control-group").remove();
      });

    });

</script>


    </body>
</html>