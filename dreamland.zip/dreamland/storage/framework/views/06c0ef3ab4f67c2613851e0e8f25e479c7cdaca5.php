   <?php echo $__env->yieldContent('exfooter'); ?>
 <!-- 
 <?php $__env->startSection('content123'); ?> -->
<h2>I am footer</h2>
<!-- <?php $__env->stopSection(); ?> -->
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>