<!DOCTPE html>
<html>
<head>
<title>View Student Records</title>
</head>
<body>
<table border = "1">
<tr>
<td>Id</td>
<td>First Name</td>
<td>Image</td>
<td>Last Name</td>
<td>City Name</td>
<td>Email</td>
</tr>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($user->id); ?></td>
<td><?php echo e($user->sellerImage); ?></td>
<td><?php echo e($user->propertyName); ?></td>
<td><?php echo e($user->propertyPrice); ?></td>
<td><?php echo e($user->mobileNo); ?></td>
<td><?php echo e($user->propertDescription); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>