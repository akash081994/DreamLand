<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
       
       <?php $__env->startSection('exheader'); ?>
   <h1>This is master page</h1>

  
        
        <?php $__env->startSection('exfooter'); ?>


</body>
</html>
<?php echo $__env->make('layouts.examplefooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.exampleheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>