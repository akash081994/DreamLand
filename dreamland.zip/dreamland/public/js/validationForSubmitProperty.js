$(function(){
            $("#propertynameErrorMessage").hide();
            $("#propertyPriceErrorMessage").hide();
            $("#mobileErrorMessage").hide();
            $("#stateErrorMessage").hide();
            $("#cityErrorMessage").hide();
            $("#bedErrorMessage").hide();
            $("#areaErrorMessage").hide();

            var errorpropertyName = false;
            var errorPrice        = false;
            var errorMobile       = false;
            var errorstate        = false;
            var errorcity         = false;
            var errorbed          = false;
            var errorarea         = false;


            $("#pronameid").focusout(function(){
                checkPropertyName();
                
            })

            $("#priceId").focusout(function(){
                checkPropertyPrice();
            })

             $("#mobileId").focusout(function(){
                checkMobileNo();
            })
              $("#wizard-picture").focusout(function(){
                ValidateFileUpload();
            })

              $("#stateId").focusout(function(){
                stateValidation();
            })

              $("#cityId").focusout(function(){
                 cityValidation();
              })
               $("#bedId").focusout(function(){
                 bedValidation();
              })

                $("#areaId").focusout(function(){
                 areaValidation();
              })


         //Start property name function
            function checkPropertyName()
            {

                 var regex = /^[a-zA-Z_\- ]+$/;
              var propertyName_length = $("#pronameid").val().length;
              if(propertyName_length < 5 || propertyName_length >50){
                 $("#propertynameErrorMessage").html("Should be between 5-50 character");
                 $("#propertynameErrorMessage").show();
                 errorpropertyName = true;
              }
              else{
                   $("#usernameErrorMessage").hide();
              }

                if(!regex.test($("#pronameid").val()))
                     {
                        $("#propertynameErrorMessage").html("Should be Alpha character");
                        $("#propertynameErrorMessage").toggle(1000);
                        errorpropertyName = true;
                     }

            }
            //End property name function

           // start Property Price function
            function checkPropertyPrice()
            {

                   var price = $("#priceId").val();
                   var priceRegix = /^[1-9]\d*(\.\d+)?$/;
                   var pricelength = $("#priceId").val().length;

                 if(!priceRegix.test(price))
                  {
                     $("#propertyPriceErrorMessage").html("Price should be Number");
                     $("#propertyPriceErrorMessage").toggle();
                      errorPrice = true;
                     
                 }
                 else
                 {
                     $("#propertyPriceErrorMessage").hide();
                 }

                if(pricelength < 5 || pricelength > 15)
                {
                    $("#propertyPriceErrorMessage").html("Price should be atleast 5 and 15 digits");
                    $("#propertyPriceErrorMessage").toggle();
                      errorPrice = true;
                }
            }
            // End Property Price function

             //Start Mobile No function
            function checkMobileNo()
            {

                   var mobileNo = $("#mobileId").val();
                   var MobileRegix = /^(\+\d{1,3}[- ]?)?\d{10}$/;
                   var mobilelength = $("#mobileId").val().length;

                 if(!MobileRegix.test(mobileNo))
                  {
                     $("#mobileErrorMessage").html("Mobile No. should be Number and 10 digits");
                     $("#mobileErrorMessage").toggle();
                      errorMobile = true;
                   }
                 else
                 {
                     $("#mobileErrorMessage").hide();
                 }

                
            }
            // end mobile No fucntion



   //Image Validation Start
                function ValidateFileUpload() {
        var fuData = document.getElementById('wizard-picture');
        var FileUploadPath = fuData.value;

//To check if user upload any file
        if (FileUploadPath == '') {
            //alert("Please upload an image");

        } else {
            var Extension = FileUploadPath.substring(
                    FileUploadPath.lastIndexOf('.') + 1).toLowerCase();

//The file uploaded is an image

if (Extension == "gif" || Extension == "png" || Extension == "bmp"
                    || Extension == "jpeg" || Extension == "jpg") {

// To Display
                if (fuData.files && fuData.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#blah').attr('src', e.target.result);
                    }

                    reader.readAsDataURL(fuData.files[0]);
                }

            } 

//The file upload is NOT an image
else {
                alert("Photo only allows file types of GIF, PNG, JPG, JPEG and BMP. ");

            }
        }
    }

    //End Image validation

//Start state Validation
     function stateValidation()
            {

                   var state = $("#stateId").val();
                   var stateRegix = /^[a-zA-Z_\- ]+$/;
                   var statelength = $("#stateId").val().length;

                 if(!stateRegix.test(state))
                  {
                     $("#stateErrorMessage").html("State should be character");
                     $("#stateErrorMessage").toggle();
                      errorstate = true;
                      //alert("test");
                     
                 }
                 else if(statelength < 3 || statelength > 15){
                        $("#stateErrorMessage").html("State should be atleast 3 and 15 character");
                        $("#stateErrorMessage").show();
                        errorstate = true;
                 }
                   else
                 {
                     $("#stateErrorMessage").hide();
                 }


                 
                
            }
            //End State Validation


function cityValidation()
            {

                   var city = $("#cityId").val();
                   var cityRegix = /^[a-zA-Z_\- ]+$/;
                   var citylength = $("#cityId").val().length;

                 if(!cityRegix.test(city))
                  {
                     $("#cityErrorMessage").html("city should be character");
                     $("#cityErrorMessage").toggle();
                      errorcity = true;
                      //alert("test");
                     
                 }
                 else if(citylength < 3 || citylength > 15){
                        $("#cityErrorMessage").html("State should be atleast 3 and 15 character");
                        $("#cityErrorMessage").show();
                        errorcity = true;
                 }
                   else
                 {
                     $("#cityErrorMessage").hide();
                 }


                 
                
            }
            //End State Validation

         function bedValidation()
            {

                   var bed = $("#bedId").val();
                   var bedRegix = /^[1-9]\d*(\.\d+)?$/;
                   var bedlength = $("#bedId").val().length;

                 if(!bedRegix.test(bed))
                  {
                     $("#bedErrorMessage").html("Bed should be Number");
                     $("#bedErrorMessage").toggle();
                      errorbed = true;
                      //alert("test");
                     
                 }
                 else if(bed <= 1 || bed >= 5){
                        $("#bedErrorMessage").html("Bed should be atleast 1 and maximum 5 ");
                        $("#bedErrorMessage").show();
                        errorbed = true;
                 }
                   else
                 {
                     $("#bedErrorMessage").hide();
                 }


         }   

          function areaValidation()
            {

                   var area = $("#areaId").val();
                   var areaRegix = /^[1-9]\d*(\.\d+)?$/;
                   var arealength = $("#areaId").val().length;

                 if(!areaRegix.test(area))
                  {
                     $("#areaErrorMessage").html("Area should be Number");
                     $("#areaErrorMessage").toggle();
                      errorarea = true;
                      //alert("test");
                     
                 }
                 else if(arealength < 5 || arealength > 15){
                        $("#areaErrorMessage").html("Area should be atleast 5 and maximum 15 digit ");
                        $("#areaErrorMessage").show();
                        errorarea = true;
                 }
                   else
                 {
                     $("#areaErrorMessage").hide();
                 }


         }  


          //DROPDOWN OF RENT AND BUY
        //     function changeddl(obj) {

        //     var text = obj.options[obj.selectedIndex].text;
        //     var ddl2 = document.querySelectorAll('#basic option');
        //     for (var i = 1; i < ddl2.length; i++) {
        //         var option = ddl2[i];
        //         option.style.display = 'none';
        //         if (text == 'Rent') {
        //             // if (['6 Months', '1 Year','2 Year','3 Year'].indexOf(option.text) > -1)
        //             //     option.style.display = 'block'
        //             alert('test');

        //         }
        //         if (text == 'Buy') {
        //             if ([].indexOf(option.text) > -1)
        //                 option.style.display = 'block'
        //         }
        //     }
        // } 
 

      


                $("#formId").submit(function(){

                    // errorUserName = false;
                    // errorPassword = false;

                    // checkPassword();
                    // checkUserName();

           
             errorpropertyName = false;
             errorPrice        = false;
             errorMobile       = false;
             errorstate        = false;
             errorcity         = false;
             errorbed          = false;
             errorarea         = false;


            checkPropertyName();
            checkPropertyPrice();
            checkMobileNo();
            ValidateFileUpload();
            stateValidation();
            cityValidation();
            bedValidation();
              

             
               

                    if(errorpropertyName == false && errorPrice == false && errorMobile == false &&  
                        errorstate  == false && errorcity == false && errorbed == false && errorarea == false)
                    {
                       return true;
                    }
                    else
                    {
                       return false;
                    }



                });
         });