<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('index', function () {
	return view('index');
});

Route::get('propertylisting', function () {
	return view('submit-property');
});

Route::get('register',function () {
	return view('register');
});
Route::get('contact',function () {
	return view('contact');
});

Route::get('subprop',function () {
	return view('submit-property');
});




Route::get('/home', 'HomeController@index')->name('home');

Route::get('/submitprop', 'SubmitPropertyController@insertform');
Route::post('insertion','SubmitPropertyController@insert');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


Route::get('/verifyemail/{token}', 'Auth\RegisterController@verify'); //This rout is use for email routing

Route::get('master', 'Controller@master');


Route::get('showlist',function (){
	  return view('proplist');
}); 



Route::get('view-records','SubmitPropertyView@show')->name('view-records'); //For view Data

Route::get('afterlogin','SubmitPropertyView@showAftrtLogin'); 

Route::get('afterlogin/{user}', 'SubmitPropertyView@showDetail');

Route::get('ind','Search@homePage');
Route::get('search','Search@search');




//    Route::get('/task',function()
// {
//     $tasks = DB::table('_tasks')->latest()->get();

//      return view('task.tasks',compact('tasks'));
// });

// Route::get('/task/{task}',function($id)
// {
  
//     $tasks = DB::table('_tasks')->find($id);
   

//      return view('task.show',compact('tasks'));
// });







